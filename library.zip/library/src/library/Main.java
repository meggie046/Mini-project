package library;

import java.util.Scanner;

	public class Main
	{


		public static void main(String[] args)
				
		{
			
		
				 Scanner file=new Scanner (System.in);
				 
					 
						{
							System.out.println("===================Library Management=========   ");
							
							
							 int choice =0;
							 
							 System.out.println("Enter the choice: \n press 1 to Admin \n press 2 to Department");
								

								 while (choice !=3)
									
								 {
									
							 choice = file.nextInt();
							
								 if(choice ==1) 
								{
								
									 Admin object1=new Admin();
								
									System.out.println("Enter student's name");

						 	object1.name =file.nextLine();object1.name=file.nextLine();

						 	System.out.println("Enter the father's name");

						 	object1.fname=file.nextLine();

						 	System.out.println("Enter user id");

						 	object1.uid=file.nextInt();

						 	System.out.println("in which semester do you study");

						 	object1.sem=file.nextInt();


						 	object1.getdata(object1.name,object1.uid,object1.fname,object1.sem);

						 	object1.setdata();
}

							else if (choice==2)
							{
							Department object2= new Department();
							object2.java();
							object2.python();
							System.out.println("  ------------------------------------   ");

						   }
							
                    } 
			}
		
	}
}
