package library;

public class Admin {

	
	
	String name ,fname;
	int uid;
	int _id;
	int sem;
	public void getdata( String name, int uid, String fname, int sem)
	{
		this.name = name ;
		
		this.fname = fname;
		this.uid = uid;
		this.sem = sem;
	}
	public void setdata() {
		System.out.println("    =======Library Management======   ");
		System.out.println("Studen's name:"+name);
		
		System.out.println("Student's fathers name:"+fname);
		
		
		
		System.out.println("user id"+uid);
		
		System.out.println("semester"+sem);
		
	}

		
}

