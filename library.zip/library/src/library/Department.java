package library;

public class Department 
   {
	     public void java()
	      {
	    	 System.out.println(" ");
	    	 System.out.println("    =======Library Management======   ");
		     String java[]={"core java","adavance java" ,"springboot","angulor","hibernet","kubernet"};
	
		     System.out.println("The books avaible in Java department are as follow");
	
		     for(int i=0;i<java.length;i++)
		     {
		    	 System.out.println(java[i]);
		     }
	      }

	   	public void python() 
	     		{
	   				System.out.println(" ");
	   				System.out.println("    =======Library Management======   ");
	     			String py[]= {"python core","python.nampy","python.pandas"};
	
	     			System.out.println("The books avaible in Python department are as follow");
	
	     			for (int j=0;j<py.length;j++)
	     			{
	     				System.out.println(py[j]);
		
	     			}

	
		}	
}